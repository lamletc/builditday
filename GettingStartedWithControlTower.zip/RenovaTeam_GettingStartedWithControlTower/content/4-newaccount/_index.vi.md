+++
title = "Thêm các Tài khoản"
date = 2021-07-31T00:38:32+07:00
weight = 4
chapter = false
pre = "<b>4. </b>"
+++

**Đăng ký các tài khoản vào AWS Control Tower**

#### Nội dung

1. [Thêm các Tài khoản đang sử dụng](1-existing-account/)
2. [Thêm Tài khoản mới với Acccount Factory](2-new-account/)
