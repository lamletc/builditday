+++
title = "Enroll account"
date = 2021-07-31T00:38:32+07:00
weight = 4
chapter = false
pre = "<b>4. </b>"
+++

**Enroll account in AWS Control Tower**

#### Contents

1. [Enroll existing account](1-existing-account/)
2. [Enroll new account using Acccount Factory](2-new-account/)
