+++
title = "Thử nghiệm sử dụng Control Tower"
date = 2020
weight = 1
chapter = true
+++

# Thử nghiệm sử dụng Control Tower

## Nội dung

1. [Tổng quan về AWS Control Tower](1-overview)
2. [Mô hình và Các tài nguyên cần thiết](2-labdiagram-requirements)
3. [Xây dựng AWS Control Tower](3-create-aws-control-tower)
4. [Thêm các Tài khoản với Account Factory](4-add-account)
5. [Thiết lập AWS Single Sign-On](5-create-aws-single-sign-on)