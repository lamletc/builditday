+++
title = "Getting started with Control Tower"
date = 2020
weight = 1
chapter = true
+++

# Getting started with Control Tower

## Table of Contents

1. [Overview AWS Control Tower](1-overview)
2. [Lab Diagram & Requirement Resources](2-labdiagram-requirements)
3. [Creating AWS Control Tower](3-create-aws-control-tower)
4. [Account Factory - Add Existing Account](4-add-account)
5. [Creating AWS Single Sign-On](5-create-aws-single-sign-on)